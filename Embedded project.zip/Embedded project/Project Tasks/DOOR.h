// door_status.h
#ifndef DOOR_STATUS_H
#define DOOR_STATUS_H
#include "tm4c123gh6pm.h"
#include <stdint.h>

uint8_t Get_Door_Status(void);

#endif // DOOR_STATUS_H
